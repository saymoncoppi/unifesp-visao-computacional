"""Base de conhecimento Zebra (defeito -> causa -> ação corretiva).

Mapeamento das 7 classes de defeito de impressão térmica para a causa provável e a
ação corretiva recomendada, com base na documentação das impressoras Zebra ZT411 /
ZT421 (Zebra Technologies, 2024). Usada tanto na recuperação por palavra-chave
quanto na montagem do contexto enviado ao LLM (Gemini) e no fallback por regras.
"""
from __future__ import annotations

from inspetor import config

# TODO: enriquecer com JSON extraído dos PDFs Zebra

FONTE = "Zebra Technologies (2024)"

# --------------------------------------------------------------------------
# Base de conhecimento (uma entrada por classe de config.CLASSES)
# --------------------------------------------------------------------------
KB: list[dict] = [
    {
        "classe": "sem_defeito",
        "aparencia": "Código limpo e nítido, barras uniformes, dentro da "
                     "especificação de qualidade.",
        "causa_provavel": "Impressão dentro da especificação; nenhum defeito "
                          "detectado.",
        "acao_corretiva": "Nada a corrigir; manter os parâmetros atuais de "
                          "darkness, velocidade e pressão.",
        "parametros": [],
        "fonte": FONTE,
    },
    {
        "classe": "cabeca_queimada",
        "aparencia": "Linhas brancas verticais contínuas / trilhas de impressão "
                     "faltando ao longo de toda a etiqueta.",
        "causa_provavel": "Elemento (dot) da cabeça de impressão danificado ou "
                          "queimado.",
        "acao_corretiva": "Acionar a assistência técnica para troca da cabeça de "
                          "impressão; elementos queimados não se recuperam com "
                          "limpeza.",
        "parametros": ["cabeca"],
        "fonte": FONTE,
    },
    {
        "classe": "ribbon_enrugado",
        "aparencia": "Linhas cinza finas e angulares (diagonais) atravessando a "
                     "impressão.",
        "causa_provavel": "Ribbon enrugado por tensão ou alinhamento incorretos no "
                          "percurso.",
        "acao_corretiva": "Corrigir a tensão e o alinhamento do ribbon; verificar o "
                          "percurso e a barra de tensão.",
        "parametros": ["ribbon"],
        "fonte": FONTE,
    },
    {
        "classe": "ponto_queimado",
        "aparencia": "Manchas escuras, borrões e barras engrossadas (excesso de "
                     "tinta/energia).",
        "causa_provavel": "Nível de darkness (temperatura de queima) alto demais.",
        "acao_corretiva": "Reduzir o darkness; se necessário, reduzir a velocidade "
                          "de impressão.",
        "parametros": ["darkness", "velocidade"],
        "fonte": FONTE,
    },
    {
        "classe": "impressao_clara",
        "aparencia": "Impressão fraca / esmaecida (faded), baixo contraste, barras "
                     "acinzentadas.",
        "causa_provavel": "Darkness baixo, mídia/ribbon incompatíveis ou velocidade "
                          "alta demais.",
        "acao_corretiva": "Elevar o darkness; usar mídia e ribbon adequados; reduzir "
                          "a velocidade se necessário.",
        "parametros": ["darkness", "midia", "ribbon"],
        "fonte": FONTE,
    },
    {
        "classe": "pressao_desigual",
        "aparencia": "Um lado da etiqueta impresso claro e o outro escuro "
                     "(gradiente lateral de densidade).",
        "causa_provavel": "Pressão desigual da cabeça de impressão sobre a mídia.",
        "acao_corretiva": "Ajustar a pressão da cabeça equilibrando os toggles "
                          "(molas de pressão) conforme a largura da mídia.",
        "parametros": ["pressao"],
        "fonte": FONTE,
    },
    {
        "classe": "cabeca_suja",
        "aparencia": "Voids e falhas pontuais nas barras (pequenas áreas não "
                     "impressas espalhadas).",
        "causa_provavel": "Cabeça de impressão suja (acúmulo de adesivo, poeira ou "
                          "resíduo de ribbon).",
        "acao_corretiva": "Limpar a cabeça de impressão e o rolete (platen) com "
                          "álcool isopropílico 99,7%.",
        "parametros": ["cabeca", "rolete"],
        "fonte": FONTE,
    },
]

# Índice por classe para busca O(1).
_POR_CLASSE: dict[str, dict] = {item["classe"]: item for item in KB}


def buscar_por_classe(classe: str) -> dict | None:
    """Retorna a entrada da KB para a classe informada, ou None se não existir."""
    if not classe:
        return None
    return _POR_CLASSE.get(classe)


def buscar(sintomas: str) -> list[dict]:
    """Recuperação simples por palavra-chave (case-insensitive).

    Procura os termos de `sintomas` na aparência, na causa provável e no nome
    (classe / rótulo em português) de cada entrada. Retorna as entradas cujo
    conteúdo contém qualquer um dos termos.
    """
    if not sintomas:
        return []
    termos = [t for t in sintomas.lower().split() if t]
    if not termos:
        return []
    resultados: list[dict] = []
    for item in KB:
        classe = item["classe"]
        alvo = " ".join([
            item.get("aparencia", ""),
            item.get("causa_provavel", ""),
            classe,
            config.CLASSE_PT.get(classe, ""),
        ]).lower()
        if any(termo in alvo for termo in termos):
            resultados.append(item)
    return resultados


def contexto_para_llm(classe: str, indicadores: dict, leitura: dict) -> str:
    """Monta o contexto textual (KB da classe + medidas) para o prompt do LLM."""
    item = buscar_por_classe(classe)
    classe_pt = config.CLASSE_PT.get(classe, classe or "desconhecida")

    linhas: list[str] = []
    linhas.append("BASE DE CONHECIMENTO ZEBRA (ZT411/ZT421)")
    linhas.append(f"Defeito classificado: {classe_pt} ({classe or '—'})")

    if item:
        params = ", ".join(item.get("parametros") or []) or "—"
        linhas.append(f"Aparência típica: {item.get('aparencia', '—')}")
        linhas.append(f"Causa provável (KB): {item.get('causa_provavel', '—')}")
        linhas.append(f"Ação corretiva (KB): {item.get('acao_corretiva', '—')}")
        linhas.append(f"Parâmetros envolvidos: {params}")
        linhas.append(f"Fonte: {item.get('fonte', FONTE)}")
    else:
        linhas.append("Nenhuma entrada correspondente na base de conhecimento.")
        linhas.append(f"Fonte: {FONTE}")

    ind = indicadores or {}
    linhas.append("")
    linhas.append("INDICADORES MEDIDOS (visão computacional):")
    linhas.append(f"- contraste: {ind.get('contraste', '—')}")
    linhas.append(f"- uniformidade: {ind.get('uniformidade', '—')}")
    linhas.append(f"- nitidez: {ind.get('nitidez', '—')}")

    lei = leitura or {}
    linhas.append("")
    linhas.append("LEITURA DO CÓDIGO:")
    linhas.append(f"- legível: {lei.get('legivel', '—')}")
    linhas.append(f"- simbologia: {lei.get('simbologia', '—')}")
    linhas.append(f"- conteúdo: {lei.get('conteudo', '—')}")

    return "\n".join(linhas)
