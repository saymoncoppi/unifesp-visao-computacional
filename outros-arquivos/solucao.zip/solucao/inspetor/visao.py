"""Visão computacional da inspeção de etiquetas (OpenCV + pyzbar + Tesseract).

Responsável por carregar a imagem, localizar a região do código de barras,
decodificá-lo (simbologia + conteúdo), extrair o texto humano-legível (OCR) e
estimar indicadores de qualidade de impressão (contraste, uniformidade, nitidez).

Regras do projeto respeitadas aqui:
- Todos os imports pesados (cv2, numpy, pyzbar, pytesseract, PIL) são LAZY, feitos
  dentro das funções — o módulo importa mesmo sem essas libs instaladas.
- Degradação graciosa: nenhuma função derruba o processo por lib/binário ausente;
  em vez disso devolve valores neutros ou o campo de erro preenchido.
"""
from __future__ import annotations


# ---------------------------------------------------------------------------
# Auxiliares internos
# ---------------------------------------------------------------------------
def _para_ndarray(caminho_ou_img):
    """Converte a entrada (caminho, ndarray ou imagem PIL) em um ndarray.

    Se `caminho_ou_img` for um caminho de arquivo, delega a `carregar_imagem`.
    Caso contrário, garante que o objeto vire um `numpy.ndarray`.
    """
    if isinstance(caminho_ou_img, (str, bytes)) or hasattr(caminho_ou_img, "__fspath__"):
        return carregar_imagem(str(caminho_ou_img))
    import numpy as np

    return np.asarray(caminho_ou_img)


def _regiao(cinza, roi):
    """Recorta a região de interesse a partir de `roi`.

    `roi` pode ser um bbox (x, y, w, h), um ndarray já recortado ou None (usa a
    imagem inteira). Qualquer inconsistência recai na imagem inteira.
    """
    if roi is None:
        return cinza
    # ROI já é uma imagem (ndarray com pelo menos 2 dimensões).
    if getattr(roi, "ndim", 0) >= 2:
        return roi
    try:
        x, y, w, h = (int(v) for v in roi)
        if w <= 0 or h <= 0:
            return cinza
        recorte = cinza[y:y + h, x:x + w]
        if getattr(recorte, "size", 0) == 0:
            return cinza
        return recorte
    except Exception:
        return cinza


# ---------------------------------------------------------------------------
# Carregamento e conversão
# ---------------------------------------------------------------------------
def carregar_imagem(caminho: str):
    """Lê a imagem do disco em BGR (via cv2.imread).

    Levanta FileNotFoundError se o arquivo não puder ser lido.
    """
    import cv2

    img = cv2.imread(str(caminho), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Não foi possível ler a imagem: {caminho}")
    return img


def para_cinza(img):
    """Converte a imagem para tons de cinza (aceita já em cinza, BGR ou BGRA)."""
    import cv2
    import numpy as np

    arr = np.asarray(img)
    if arr.ndim == 2:
        return arr
    if arr.ndim == 3 and arr.shape[2] == 1:
        return arr[:, :, 0]
    if arr.ndim == 3 and arr.shape[2] == 4:
        return cv2.cvtColor(arr, cv2.COLOR_BGRA2GRAY)
    return cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)


# ---------------------------------------------------------------------------
# Segmentação da região do código
# ---------------------------------------------------------------------------
def segmentar_codigo(cinza):
    """Detecta a região do código de barras na imagem em cinza.

    Estratégia: gradiente (Scharr = Sobel x - Sobel y) -> convertScaleAbs ->
    blur -> threshold de Otsu -> morfologia (close + erode + dilate) ->
    maior contorno -> boundingRect.

    Retorna (roi_cinza, (x, y, w, h)) quando encontra a região, ou
    (cinza, None) se não localizar nada ou faltar alguma biblioteca.
    """
    try:
        import cv2
    except Exception:
        return cinza, None

    try:
        # Gradiente com Scharr (ksize=-1 no Sobel) e diferença horizontal-vertical:
        # realça as barras verticais do código de barras.
        grad_x = cv2.Sobel(cinza, ddepth=cv2.CV_32F, dx=1, dy=0, ksize=-1)
        grad_y = cv2.Sobel(cinza, ddepth=cv2.CV_32F, dx=0, dy=1, ksize=-1)
        gradiente = cv2.subtract(grad_x, grad_y)
        gradiente = cv2.convertScaleAbs(gradiente)

        # Suaviza para juntar as barras em um único blob.
        borrada = cv2.blur(gradiente, (9, 9))
        _, limiar = cv2.threshold(borrada, 0, 255,
                                  cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Morfologia: fecha os vãos entre barras e limpa ruído.
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (21, 7))
        fechada = cv2.morphologyEx(limiar, cv2.MORPH_CLOSE, kernel)
        fechada = cv2.erode(fechada, None, iterations=4)
        fechada = cv2.dilate(fechada, None, iterations=4)

        # Maior contorno = candidato à região do código.
        achados = cv2.findContours(fechada.copy(), cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)
        contornos = achados[0] if len(achados) == 2 else achados[1]
        if not contornos:
            return cinza, None

        maior = max(contornos, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(maior)
        if w <= 0 or h <= 0:
            return cinza, None

        roi = cinza[y:y + h, x:x + w]
        return roi, (int(x), int(y), int(w), int(h))
    except Exception:
        return cinza, None


# ---------------------------------------------------------------------------
# Decodificação do código de barras (pyzbar)
# ---------------------------------------------------------------------------
def decodificar(caminho_ou_img) -> dict:
    """Decodifica o código de barras usando pyzbar.

    Tenta a imagem em cinza e uma versão limiarizada (Otsu). A simbologia é
    normalizada para maiúsculas (ex.: "CODE128", "EAN13", "QRCODE").

    Retorna o dict do contrato:
        {"legivel": bool|None, "simbologia": str|None, "conteudo": str|None,
         "n_simbolos": int, "erro": str|None}
    O campo "erro" é preenchido quando pyzbar/zbar não estão disponíveis.
    """
    resultado = {
        "legivel": None,
        "simbologia": None,
        "conteudo": None,
        "n_simbolos": 0,
        "erro": None,
    }

    try:
        from pyzbar import pyzbar
    except Exception:
        # Falta o pacote pyzbar ou a biblioteca nativa libzbar.
        resultado["erro"] = "pyzbar ausente"
        return resultado

    # Obtém o ndarray da entrada.
    try:
        arr = _para_ndarray(caminho_ou_img)
    except Exception as exc:
        resultado["erro"] = f"falha ao carregar imagem: {exc}"
        return resultado

    # Monta as variações a tentar: cinza e limiarizada (Otsu).
    imagens = []
    try:
        cinza = para_cinza(arr)
        imagens.append(cinza)
    except Exception:
        cinza = None
        imagens.append(arr)

    if cinza is not None:
        try:
            import cv2

            _, limiar = cv2.threshold(cinza, 0, 255,
                                      cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            imagens.append(limiar)
        except Exception:
            pass

    simbolos = []
    for imagem in imagens:
        try:
            achados = pyzbar.decode(imagem)
        except Exception as exc:
            resultado["erro"] = f"pyzbar/zbar indisponível: {exc}"
            achados = []
        if achados:
            simbolos = achados
            resultado["erro"] = None
            break

    resultado["n_simbolos"] = len(simbolos)
    if simbolos:
        primeiro = simbolos[0]
        resultado["legivel"] = True
        try:
            resultado["simbologia"] = str(primeiro.type).upper()
        except Exception:
            resultado["simbologia"] = None
        try:
            resultado["conteudo"] = primeiro.data.decode("utf-8", errors="replace")
        except Exception:
            resultado["conteudo"] = str(getattr(primeiro, "data", None))
    elif resultado["erro"] is None:
        resultado["legivel"] = False

    return resultado


# ---------------------------------------------------------------------------
# OCR do texto humano-legível (Tesseract)
# ---------------------------------------------------------------------------
def ocr_texto(img_ou_roi) -> str:
    """Extrai o texto legível por humanos via Tesseract (pytesseract).

    Aceita um ndarray, uma imagem PIL ou um caminho de arquivo. Devolve "" em
    qualquer falha (Tesseract/pytesseract ausentes, imagem inválida etc.).
    """
    try:
        import pytesseract
    except Exception:
        return ""

    try:
        entrada = img_ou_roi
        if isinstance(img_ou_roi, (str, bytes)) or hasattr(img_ou_roi, "__fspath__"):
            entrada = carregar_imagem(str(img_ou_roi))
        texto = pytesseract.image_to_string(entrada)
        return (texto or "").strip()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Indicadores de qualidade
# ---------------------------------------------------------------------------
def indicadores(cinza, roi=None) -> dict:
    """Estima indicadores de qualidade de impressão sobre a ROI.

    - contraste  = (Imax - Imin) / 255 na ROI.
    - uniformidade = 1 - (desvio-padrão do perfil de colunas / 128), em [0, 1].
    - nitidez    = min(1, variância do Laplaciano / 1000).

    Todos os valores são float arredondados a 3 casas. Em caso de falta de
    biblioteca ou erro, devolve valores neutros (0.0).
    """
    neutro = {"contraste": 0.0, "uniformidade": 0.0, "nitidez": 0.0}

    try:
        import cv2
        import numpy as np
    except Exception:
        return neutro

    try:
        regiao = _regiao(cinza, roi)
        regiao_f = np.asarray(regiao, dtype=np.float64)
        if regiao_f.size == 0:
            return neutro

        # Contraste: amplitude de intensidade normalizada.
        imax = float(regiao_f.max())
        imin = float(regiao_f.min())
        contraste = (imax - imin) / 255.0

        # Uniformidade: quanto mais uniforme o perfil de colunas, maior o valor.
        perfil_colunas = regiao_f.mean(axis=0)
        uniformidade = 1.0 - (float(perfil_colunas.std()) / 128.0)
        uniformidade = max(0.0, min(1.0, uniformidade))

        # Nitidez: variância do Laplaciano normalizada.
        laplaciano = cv2.Laplacian(regiao_f, cv2.CV_64F)
        nitidez = min(1.0, float(laplaciano.var()) / 1000.0)

        return {
            "contraste": round(float(contraste), 3),
            "uniformidade": round(float(uniformidade), 3),
            "nitidez": round(float(nitidez), 3),
        }
    except Exception:
        return neutro
