"""Configuração central do projeto (constantes compartilhadas por todos os módulos)."""
from __future__ import annotations

import os
from pathlib import Path

# --------------------------------------------------------------------------
# Caminhos
# --------------------------------------------------------------------------
RAIZ = Path(__file__).resolve().parent.parent            # .../solucao
PROJETO = RAIZ.parent                                     # .../artigo
DATASET_DIR = Path(os.environ.get("DATASET_DIR", PROJETO / "dataset_sintetico"))
LABELS_CSV = DATASET_DIR / "labels.csv"
MODELOS_DIR = RAIZ / "modelos"
MODELO_PATH = Path(os.environ.get("MODELO_PATH", MODELOS_DIR / "classificador_defeitos.pt"))

# --------------------------------------------------------------------------
# Classes de defeito (mesma taxonomia de gerar_dataset.py)
# A ORDEM define o índice usado pela CNN — não reordenar sem retreinar.
# --------------------------------------------------------------------------
CLASSES = [
    "sem_defeito",
    "cabeca_queimada",
    "ribbon_enrugado",
    "ponto_queimado",
    "impressao_clara",
    "pressao_desigual",
    "cabeca_suja",
]

CLASSE_PT = {
    "sem_defeito": "Sem defeito",
    "cabeca_queimada": "Elemento da cabeça danificado",
    "ribbon_enrugado": "Ribbon enrugado",
    "ponto_queimado": "Ponto queimado (darkness alto)",
    "impressao_clara": "Impressão clara (darkness baixo)",
    "pressao_desigual": "Pressão desigual da cabeça",
    "cabeca_suja": "Cabeça de impressão suja (voids)",
}

# --------------------------------------------------------------------------
# Modelo / visão
# --------------------------------------------------------------------------
BACKBONE = "mobilenet_v3_small"     # backbone leve (transferência de aprendizado)
IMG_SIZE = 224                      # entrada da CNN
MEAN = (0.485, 0.456, 0.406)        # normalização ImageNet
STD = (0.229, 0.224, 0.225)

# --------------------------------------------------------------------------
# LLM / ADK
# --------------------------------------------------------------------------
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY", "")   # se vazio -> fallback por regras


def tem_gemini() -> bool:
    """Há chave de API configurada para usar o Gemini?"""
    return bool(os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY"))


def num_classes() -> int:
    return len(CLASSES)
