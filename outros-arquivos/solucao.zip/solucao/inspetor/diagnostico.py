"""Diagnóstico da causa provável e da correção sugerida.

Combina o LLM (Gemini) com um fallback determinístico por regras sobre a base de
conhecimento Zebra. O Gemini é opcional: só é usado quando há chave de API
configurada e a biblioteca está disponível; qualquer falha cai graciosamente no
fallback por regras. O import de `google.genai` é sempre LAZY (dentro da função).
"""
from __future__ import annotations

import json

from inspetor import config, kb


def diagnosticar(defeito: dict, leitura: dict, indicadores: dict,
                 usar_gemini: bool = True) -> dict:
    """Determina a causa provável e a correção sugerida para o defeito.

    Retorna um dicionário com as chaves:
    ``causa_provavel``, ``correcao_sugerida``, ``fundamentacao``, ``fonte`` e
    ``via`` ("gemini" ou "regras"). Nunca levanta exceção: em qualquer falha do
    LLM, recorre ao fallback por regras sobre a base de conhecimento.
    """
    defeito = defeito or {}
    classe = defeito.get("classe")

    if usar_gemini and config.tem_gemini():
        resultado = _diagnosticar_com_gemini(classe, leitura, indicadores)
        if resultado is not None:
            return resultado

    return _diagnosticar_por_regras(classe, indicadores)


def _diagnosticar_com_gemini(classe: str | None, leitura: dict,
                             indicadores: dict) -> dict | None:
    """Tenta diagnosticar via Gemini. Retorna None em qualquer falha."""
    try:
        from google import genai   # import LAZY (só quando realmente for usar)

        contexto = kb.contexto_para_llm(classe, indicadores or {}, leitura or {})
        prompt = (
            "Você é um especialista em impressão térmica de etiquetas Zebra.\n"
            "Com base na base de conhecimento e nos indicadores medidos abaixo, "
            "diagnostique a causa provável do defeito e a correção sugerida.\n\n"
            f"{contexto}\n\n"
            "Responda ESTRITAMENTE em JSON, sem texto extra, no formato:\n"
            '{"causa_provavel": "...", "correcao_sugerida": "...", '
            '"fundamentacao": "..."}\n'
            "Escreva em português."
        )

        cliente = genai.Client()
        resposta = cliente.models.generate_content(
            model=config.GEMINI_MODEL,
            contents=prompt,
        )
        texto = (getattr(resposta, "text", None) or "").strip()
        dados = _extrair_json(texto)
        if not dados:
            return None

        causa = (dados.get("causa_provavel") or "").strip()
        correcao = (dados.get("correcao_sugerida") or "").strip()
        fundamentacao = (dados.get("fundamentacao") or "").strip()
        if not causa or not correcao:
            return None

        item = kb.buscar_por_classe(classe)
        fonte = item.get("fonte", kb.FONTE) if item else kb.FONTE
        return {
            "causa_provavel": causa,
            "correcao_sugerida": correcao,
            "fundamentacao": fundamentacao,
            "fonte": fonte,
            "via": "gemini",
        }
    except Exception:
        # Qualquer erro (lib ausente, rede, cota, JSON inválido) -> fallback.
        return None


def _extrair_json(texto: str) -> dict | None:
    """Extrai um objeto JSON do texto da resposta (tolerante a cercas ```)."""
    if not texto:
        return None
    try:
        return json.loads(texto)
    except Exception:
        pass
    inicio = texto.find("{")
    fim = texto.rfind("}")
    if inicio != -1 and fim != -1 and fim > inicio:
        try:
            return json.loads(texto[inicio:fim + 1])
        except Exception:
            return None
    return None


def _diagnosticar_por_regras(classe: str | None, indicadores: dict) -> dict:
    """Fallback determinístico usando a base de conhecimento Zebra."""
    item = kb.buscar_por_classe(classe)
    if item is None:
        return {
            "causa_provavel": "Causa não identificada.",
            "correcao_sugerida": "Verificar manualmente os parâmetros de impressão "
                                 "(darkness, velocidade, pressão) e a limpeza da "
                                 "cabeça.",
            "fundamentacao": "Defeito sem correspondência na base de conhecimento "
                             f"Zebra (classe: {classe or '—'}).",
            "fonte": kb.FONTE,
            "via": "regras",
        }

    ind = indicadores or {}
    fundamentacao = (
        f"Classificação '{config.CLASSE_PT.get(classe, classe)}' associada, na base "
        f"de conhecimento Zebra, à aparência: {item.get('aparencia', '—')} "
        f"Indicadores medidos — contraste={ind.get('contraste', '—')}, "
        f"uniformidade={ind.get('uniformidade', '—')}, "
        f"nitidez={ind.get('nitidez', '—')}."
    )
    return {
        "causa_provavel": item.get("causa_provavel", ""),
        "correcao_sugerida": item.get("acao_corretiva", ""),
        "fundamentacao": fundamentacao,
        "fonte": item.get("fonte", kb.FONTE),
        "via": "regras",
    }
