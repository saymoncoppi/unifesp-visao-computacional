"""API HTTP do inspetor de etiquetas (FastAPI).

Sobe um servidor que serve a interface de chat e expõe o pipeline de análise.

Rotas:
    GET  /          -> página de chat (app/chat.html)
    GET  /saude     -> {"status": "ok"}
    POST /analisar  -> recebe uma imagem (campo `imagem`) e devolve o laudo JSON.
                       Query opcional `adk=true` usa o grafo multiagente (ADK).

Rodar:
    # uvicorn app.api:app --reload
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse

from inspetor.ferramentas import analisar_imagem

# Caminho da página de chat, ao lado deste módulo.
_CHAT_HTML = Path(__file__).resolve().parent / "chat.html"

app = FastAPI(
    title="Inspetor de Etiquetas",
    description="Analisa etiquetas de código de barras e emite um laudo de defeitos.",
    version="0.1.0",
)


@app.get("/", response_class=HTMLResponse)
def raiz() -> HTMLResponse:
    """Serve a interface de chat (HTML autossuficiente)."""
    try:
        html = _CHAT_HTML.read_text(encoding="utf-8")
    except OSError as exc:
        return HTMLResponse(
            f"<h1>Interface indisponível</h1><p>{exc}</p>",
            status_code=500,
        )
    return HTMLResponse(html)


@app.get("/saude")
def saude() -> dict:
    """Verificação de saúde do serviço."""
    return {"status": "ok"}


@app.post("/analisar")
async def analisar(imagem: UploadFile = File(...), adk: bool = False) -> JSONResponse:
    """Recebe uma imagem, roda a análise e devolve o laudo.

    A imagem é gravada em um arquivo temporário (o pipeline trabalha com caminhos
    de arquivo) e removida ao final, independentemente do resultado.
    """
    sufixo = Path(imagem.filename or "").suffix or ".png"
    caminho_temp = None
    try:
        conteudo = await imagem.read()
        with tempfile.NamedTemporaryFile(suffix=sufixo, delete=False) as tmp:
            tmp.write(conteudo)
            caminho_temp = tmp.name

        if adk:
            try:
                from inspetor.agentes import analisar_via_adk

                laudo = await analisar_via_adk(caminho_temp)
            except Exception as exc:  # noqa: BLE001 - fallback deliberado
                laudo = analisar_imagem(caminho_temp)
                laudo.setdefault("erros", []).append(
                    f"ADK indisponível ({exc}); usado pipeline direto."
                )
        else:
            laudo = analisar_imagem(caminho_temp)

        return JSONResponse(laudo)
    except Exception as exc:  # noqa: BLE001 - não vazar stacktrace ao cliente
        return JSONResponse(
            {"erro": f"Falha ao analisar a imagem: {exc}"},
            status_code=500,
        )
    finally:
        if caminho_temp:
            try:
                os.remove(caminho_temp)
            except OSError:
                pass


# uvicorn app.api:app --reload
